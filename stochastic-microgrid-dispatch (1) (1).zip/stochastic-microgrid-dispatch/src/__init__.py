"""Stochastic microgrid dispatch package."""
